
def create_tables(db):
    """Create a database tables for the application given a database connection

    The database has a table named likes with the following fields:
        - thing: a text field

    """
    cursor = db.cursor()
    cursor.execute("DROP TABLE IF EXISTS likes")
    cursor.execute("""
    CREATE TABLE likes (
       thing text
    )
    """)
    db.commit()

    for thing in ['apple', 'avocado', 'biscuit', 'donut', 'date']:
        store_like(db, thing)


def store_like(db, like):
    """Store a new like in the database in an insecure
    manner"""

    cursor = db.cursor()

    # here is a vulnerability - using string concatenation rather than
    # the ? placeholder to construct the query
    query = "INSERT INTO likes (thing) VALUES ('"+ like + "')"
    print("Q:", query)
    # we need to use executescript to allow more than one sql statement
    # to be executed
    cursor.executescript(query)
    db.commit()


def get_likes(db, prefix):
    """Return a list of likes from the database
    starting with this prefix
    in an insecure manner"""

    cursor = db.cursor()
    # make the query with string concatenation
    query = "SELECT thing FROM likes WHERE thing LIKE '" + prefix + "%'"
    print("Q:", query)
    # run with execute this time since executescript doesn't
    # let us see the result
    cursor.execute(query)
    result = []
    for row in cursor:
        result.append(row[0])
    return result
