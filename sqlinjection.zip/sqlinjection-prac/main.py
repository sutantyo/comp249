from bottle import Bottle, template, request, redirect, static_file
import model

app = Bottle()


@app.route('/')
def index(db):
    """Home page"""

    prefix = request.query.prefix or 'd'

    if prefix in 'abc':
        prefix = 'd'

    info = {
        'title': 'Welcome Home!',
        'prefix': prefix,
        'likes': model.get_likes(db, prefix)
    }

    return template('index', info)



@app.post('/likes')
def like(db):
    """Process like form post request"""

    # get the form field
    likes = request.forms.get('likes')

    if likes:
        model.store_like(db, likes)

    return redirect('/')


@app.route('/static/<filepath:path>')
def static(filepath):

    return static_file(filepath, root='static')


if __name__ == "__main__":
    from bottle.ext import sqlite
    import sqlite3
    DATABASE_NAME = 'comp249.db'
    db = sqlite3.connect(DATABASE_NAME)
    model.create_tables(db)

    # install the database plugin
    app.install(sqlite.Plugin(dbfile=DATABASE_NAME))
    app.run(debug=True, port=8010)
